<?php


class PostImg extends ObjectModel

{

	/** @var string Name */

	public $id_img;	

	/** @var string Name */

	
	/** @var string Name */

	public $id_post;	
	
	
	

	public $img;	

    /**

     * @see ObjectModel::$definition

     */

    public static $definition = array(

        'table' => 'cms_blog_img',

        'primary' => 'id_img',

        'multilang' => FALSE,

        'fields' => array(            
			
            'id_post' =>array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),				
			'img'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'size' => 32),	            	

        ),

    );
	
	
	 public static function loadByIdPost($id_post){

        $result = Db::getInstance()->getRow('
		
            SELECT  *

            FROM `'._DB_PREFIX_.'cms_blog_img` cmb

             WHERE  cmb.`id_post`='.(int)$id_post

        );        

        return new PostImg($result['id_img']);

    }
	
	public function processImage($FILES,$id) { 

            if (isset($FILES['BANNER_IMAGE']) && isset($FILES['BANNER_IMAGE']['tmp_name']) && !empty($FILES['BANNER_IMAGE']['tmp_name'])) {

                if ($error = ImageManager::validateUpload($FILES['BANNER_IMAGE'], 4000000))

                    return $message='Invalid image';

                else {

                    $ext = substr($FILES['BANNER_IMAGE']['name'], strrpos($FILES['BANNER_IMAGE']['name'], '.') + 1);

                    $file_name = $id . '.' . $ext;

                    $path = _PS_MODULE_DIR_ .'cmsblogpro/uploads/' . $file_name;       



                    if (!move_uploaded_file($FILES['BANNER_IMAGE']['tmp_name'], $path))

                        return $message='An error occurred while attempting to upload the file.';

                    else {

                        $posts_types =ImageType::getImagesTypes('products');

                        foreach ($posts_types as  $image_type)

			{

            $dir = _PS_MODULE_DIR_ .'cmsblogpro/uploads/'.$id.'-'.stripslashes($image_type['name']).'.jpg';
            if (file_exists($dir))
						unlink($dir);

			}

			foreach ($posts_types as $image_type)

			{

             ImageManager::resize($path,_PS_MODULE_DIR_ .'cmsblogpro/uploads/'.$id.'-'.stripslashes($image_type['name']).'.jpg',

            (int)$image_type['width'], (int)$image_type['height']

            );

			}

                    }

                }

            } 		

			

    }


	

}



