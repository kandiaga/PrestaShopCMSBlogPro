<?php
/*
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2018 PrestaShop SA
*  @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

class cmsblogpropostModuleFrontController extends ModuleFrontController
{
	
	//public $php_self = 'post';
	public $assignCase;
	public $cms;
	public $cms_category;
	public $ssl = false;
	
	
	public function setMedia()
	{
		parent::setMedia();

		if ($this->assignCase == 1)
			$this->addJS(_THEME_JS_DIR_.'cms.js');

		$this->addCSS(_THEME_CSS_DIR_.'cms.css');
	}
	
	public function canonicalRedirection($canonicalURL = '')
	{
		if (Tools::getValue('live_edit'))
			return ;
		if (Validate::isLoadedObject($this->cms) && ($canonicalURL =$this->context->link->getModuleLink('cmsblogpro', 'post') ))
			parent::canonicalRedirection($canonicalURL);
		else if (Validate::isLoadedObject($this->cms_category) && ($canonicalURL = $this->context->link->getModuleLink('cmsblogpro', 'post')))
			parent::canonicalRedirection($canonicalURL);
	}
	
	
	/**
	 * Initialize cms controller
	 * @see FrontController::init()
	 */
	public function init()
	{
		if ($id_cms = (int)Tools::getValue('id_cms'))
			$this->cms = new CMS($id_cms, $this->context->language->id);
		else if ($id_cms_category = (int)Tools::getValue('id_cms_category'))
			$this->cms_category = new CMSCategory($id_cms_category, $this->context->language->id);

		if (Configuration::get('PS_SSL_ENABLED') && Tools::getValue('content_only') && Tools::getValue('id_cms') == (int)Configuration::get('PS_CONDITIONS_CMS_ID') && Validate::isLoadedObject($this->cms))
			$this->ssl = true;
		
		parent::init();

		$this->canonicalRedirection();

		// assignCase (1 = CMS page, 2 = CMS category)
		if (Validate::isLoadedObject($this->cms))
		{
			$adtoken = Tools::getAdminToken('AdminCmsContent'.(int)Tab::getIdFromClassName('AdminCmsContent').(int)Tools::getValue('id_employee'));
			if (!$this->cms->isAssociatedToShop() || !$this->cms->active && Tools::getValue('adtoken') != $adtoken)
			{
				header('HTTP/1.1 404 Not Found');
				header('Status: 404 Not Found');
			}
			else
				$this->assignCase = 1;
		}
		else if (Validate::isLoadedObject($this->cms_category))
			$this->assignCase = 2;
		else
		{
			header('HTTP/1.1 404 Not Found');
			header('Status: 404 Not Found');
		}
	}

	/**
	 * Assign template vars related to page content
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
			
			parent::initContent();	
        $ps_version=_PS_VERSION_;				
		
		
		$currency = $this->context->currency;

			
		if ($id_cms = (int)Tools::getValue('id_cms'))
			$this->cms = new CMS($id_cms, $this->context->language->id);
		else if ($id_cms_category = (int)Tools::getValue('id_cms_category'))
			$this->cms_category = new CMSCategory($id_cms_category, $this->context->language->id);

		if (Configuration::get('PS_SSL_ENABLED') && Tools::getValue('content_only') && Tools::getValue('id_cms') == (int)Configuration::get('PS_CONDITIONS_CMS_ID') && Validate::isLoadedObject($this->cms))
			$this->ssl = true;

		$parent_cat = new CMSCategory(1, $this->context->language->id);
		$this->context->smarty->assign('id_current_lang', $this->context->language->id);
		$this->context->smarty->assign('home_title', $parent_cat->name);
		$this->context->smarty->assign('cgv_id', Configuration::get('PS_CONDITIONS_CMS_ID'));
		if (isset($this->cms->id_cms_category) && $this->cms->id_cms_category)
			
		   //$path = Tools::getFullPath($this->cms->id_cms_category, $this->cms->meta_title, 'CMS'); 1.6 only
		     $path = $this->context->link->getCMSCategoryLink($this->cms->id_cms_category, $this->cms->meta_title);
		else if (isset($this->cms_category->meta_title))
			//$path = Tools::getFullPath(1, $this->cms_category->meta_title, 'CMS'); 1.6 only
		    $path = $this->context->link->getCMSCategoryLink(1, $this->cms_category->meta_title);
			
		$id_lang=(int)$this->context->language->id;
        $cat=new CMSCategory($this->cms->id_cms_category,$this->context->language->id);		
		$id_cms_category_nka=NSCmsBlogPro::loadDefaultCatery();
	    $cmsCats=NSCmsBlogPro::getCMSCategories(false, (int)$id_cms_category_nka);
		if ($this->assignCase == 1)
		{
			$this->context->smarty->assign(array(
				'cms' => $this->cms,
				'content_only' => (int)(Tools::getValue('content_only')),
				'path' => $path,
				'cat'=>$cat,
				'productsViewedObj' =>$this->getViewed() ,
				'id_cms'=>(int)Tools::getValue('id_cms'),
				'cmsCats' =>$cmsCats,
				'to_day'=>Date('y-m-d H:i:s'),
				'shop_name'=>Configuration::get('PS_SHOP_NAME'),
				'shop_description'=>Configuration::get('PS_SHOP_DESCRIPTION'),
				'new_products' =>Product::getNewProducts($id_lang, 0, (int)Configuration::get('NEW_PRODUCTS_NBR')),
				'view_post_link' => $this->context->link->getModuleLink('cmsblogpro', 'post'),
				'related_posts'=>$this->getRelatedPosts($this->cms->id_cms_category),
				'currency'=>$currency,
				'base_dir'=>Tools::getHttpHost(true).__PS_BASE_URI__,
				'body_classes' => array($this->php_self.'-'.$this->cms->id, $this->php_self.'-'.$this->cms->link_rewrite)
			));

			if ($this->cms->indexation == 0)
				$this->context->smarty->assign('nobots', true);
		}
		else if ($this->assignCase == 2)
		{
			$this->context->smarty->assign(array(
				'category' => $this->cms_category, //for backward compatibility
				'cms_category' => $this->cms_category,
				'sub_category' => $this->cms_category->getSubCategories($this->context->language->id),
				'cms_pages' => CMS::getCMSPages($this->context->language->id, (int)($this->cms_category->id), true, (int)$this->context->shop->id),
				'path' => ($this->cms_category->id !== 1) ? Tools::getPath($this->cms_category->id, $this->cms_category->name, false, 'CMS') : '',
				'body_classes' => array($this->php_self.'-'.$this->cms_category->id, $this->php_self.'-'.$this->cms_category->link_rewrite)
			));
		}
		
		
		if($ps_version>=1.7)
		{
		  $template='module:'.$this->module->name.'/views/templates/front/post.tpl';	
		   $this->setTemplate($template); 		
		} 
		
		if($ps_version<1.7) 		     
		{ 
		 $this->setTemplate('post.tpl');
		
		}   
		
	
		
	}
	
	
	
	public function getRelatedPosts($id_cms_category){
	
	    return NSCmsBlogPro::getCMSPages($id_cms_category,false);
	
	}
	
		/* viewed products*/
	
	
		public function getViewed()
	{
		$productsViewedObj = array();
		
		$result = (isset($this->context->cookie->viewed) && !empty($this->context->cookie->viewed)) ? array_slice(array_reverse(explode(',', $this->context->cookie->viewed)), 0, 8) : array();
        $productsViewed =array_unique($result);	
		if (count($productsViewed))
		{
			$defaultCover = Language::getIsoById($this->context->cookie->id_lang).'-default';

			$productIds = implode(',', $productsViewed);
			$productsImages = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
			SELECT MAX(image_shop.id_image) id_image, p.id_product,p.price, il.legend, product_shop.active, pl.name, pl.description_short, pl.link_rewrite, cl.link_rewrite AS category_rewrite
			FROM '._DB_PREFIX_.'product p
			'.Shop::addSqlAssociation('product', 'p').'
			LEFT JOIN '._DB_PREFIX_.'product_lang pl ON (pl.id_product = p.id_product'.Shop::addSqlRestrictionOnLang('pl').')
			LEFT JOIN '._DB_PREFIX_.'image i ON (i.id_product = p.id_product)'.
			Shop::addSqlAssociation('image', 'i', false, 'image_shop.cover=1').'
			LEFT JOIN '._DB_PREFIX_.'image_lang il ON (il.id_image = image_shop.id_image)
			LEFT JOIN '._DB_PREFIX_.'category_lang cl ON (cl.id_category = product_shop.id_category_default'.Shop::addSqlRestrictionOnLang('cl').')
			WHERE p.id_product IN ('.$productIds.')
			AND pl.id_lang = '.(int)($this->context->cookie->id_lang).'
			AND cl.id_lang = '.(int)($this->context->cookie->id_lang).'
			GROUP BY product_shop.id_product'
			);

			$productsImagesArray = array();
			foreach ($productsImages as $pi)
				$productsImagesArray[$pi['id_product']] = $pi;

			
			foreach ($productsViewed as $productViewed)
			{
				$obj = (object)'Product';
				if (!isset($productsImagesArray[$productViewed]) || (!$obj->active = $productsImagesArray[$productViewed]['active']))
					continue;
				else
				{
					$obj->id = (int)($productsImagesArray[$productViewed]['id_product']);
					$obj->price= (int)($productsImagesArray[$productViewed]['price']);
					$obj->id_image = (int)$productsImagesArray[$productViewed]['id_image'];
					$obj->cover = (int)($productsImagesArray[$productViewed]['id_product']).'-'.(int)($productsImagesArray[$productViewed]['id_image']);
					$obj->legend = $productsImagesArray[$productViewed]['legend'];
					$obj->name = $productsImagesArray[$productViewed]['name'];
					$obj->description_short = $productsImagesArray[$productViewed]['description_short'];
					$obj->link_rewrite = $productsImagesArray[$productViewed]['link_rewrite'];
					$obj->category_rewrite = $productsImagesArray[$productViewed]['category_rewrite'];
					// $obj is not a real product so it cannot be used as argument for getProductLink()
					$obj->product_link = $this->context->link->getProductLink($obj->id, $obj->link_rewrite, $obj->category_rewrite);

					if (!isset($obj->cover) || !$productsImagesArray[$productViewed]['id_image'])
					{
						$obj->cover = $defaultCover;
						$obj->legend = '';
					}
					$productsViewedObj[] = $obj;
				}
			}

			if (!count($productsViewedObj))
				return;

			

			
		}
		return $productsViewedObj;
	}
	
	
	
	
	
}
