<?php
if (!defined('_PS_VERSION_')){
  exit;
 } 
 
require_once(dirname(__FILE__) . '/classes/NSCmsBlogPro.php');  
require_once(dirname(__FILE__) . '/classes/PostImg.php');  




  class CmsBlogPro extends Module
  
  { 
  
  public function __construct()
  {
    $this->name = 'cmsblogpro';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'NdiagaSoft';
    $this->need_instance = 0;
    $this->ps_versions_compliancy = array('min' => '1.5', 'max' =>_PS_VERSION_);
    $this->bootstrap = true;
 
    parent::__construct();
 
    $this->displayName = $this->l('CMS Blog Pro');
    $this->description = $this->l('Create a simple blog with CMS pages.');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); 
    
  }
  
  
  
  public function install()
{
  if (Shop::isFeatureActive())
    Shop::setContext(Shop::CONTEXT_ALL);
	$sql = array();
	
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'cmsblog_pro` (
                  `id_cmsblog_pro` int(10) unsigned NOT NULL AUTO_INCREMENT,                  
				  `id_cms_category` int(10) NOT NULL,				  	
                   `number_post` int(10) NOT NULL,				  
				  `cmsblog_img` varchar(250) NULL,                  				  
                  PRIMARY KEY (`id_cmsblog_pro`)
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
				
		$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'cms_blog_img` (
                  `id_img` int(10) unsigned NOT NULL AUTO_INCREMENT,                  
				  `id_post` int(10) NOT NULL UNIQUE,                   			  
				  `img` varchar(250) NULL,                  				  
                  PRIMARY KEY (`id_img`)
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
				
		
      
 
  if (!parent::install() ||  	
    !$this->registerHook('header')||	
	!$this->registerHook('displayHome')||
	!$this->registerHook('displayTopColumn')||
    !$this->runSql($sql)||
    !Configuration::updateValue('POST_NUMBER',5) 	
  )
    return false;
 
  return true;
}
       public function uninstall()
    {
        $sql = array();
	
        $sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'cmsblog_pro`';
		$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'cms_blog_img`';
		
		
		if (!parent::uninstall()||
		    !$this->runSql($sql)||
            !Configuration::deleteByName('POST_NUMBER')			
           )
                return false;
              $this->emptyUploads();
           return true;
    }
	
	
   public function runSql($sql) {
        foreach ($sql as $s) {
			if (!Db::getInstance()->Execute($s)){
				return FALSE;
			}
        }
        
        return TRUE;
    }	
  
        public function getContent()
    {
          $output = null;
		  
		  
		  
		  
		    if (Tools::isSubmit('submit'.$this->name))
      {
        $my_module_name =Tools::getValue('POST_NUMBER');
		$test_one=Tools::getValue('test_one');
        if (!$my_module_name || empty($my_module_name) || !Validate::isGenericName($my_module_name))
            $output .= $this->displayError($this->l('Invalid Configuration value'));
        else
        {
            Configuration::updateValue('POST_NUMBER', $my_module_name);
			Configuration::updateValue('test_one', $test_one);
			$cat=new NSCmsBlogPro();
			$cat->number_post=$my_module_name;
			$cat->id_cms_category=Tools::getValue('id_cms_category');
			$cat->cmsblog_img='';
			
			if(!empty($cat) && empty($cat->id)){ 
			$cat->add();
			}
			else { $cat->update();}
		
            $output.= $this->displayConfirmation($this->l('Settings updated'));
        }
      }  	  
			
         if(Tools::isSubmit('viewcms_category_lang') && Tools::getValue('id_cms_category')!='')	
		   
		   {
		   
		   $output.=$this->renderPages();
		   
		   }
		   
		   elseif(Tools::isSubmit('updatecms_blog_img') && Tools::getValue('id_cms')!=''){
		  
		    
		    $output.=$this->renderAddImage();
		   
		   }
		   
		   elseif(Tools::isSubmit('viewcms_blog_img') && Tools::getValue('id_cms')!=''){
		  
		    $output.=$this->getPostDetails();		
		   
		   }
		   
		  elseif(Tools::isSubmit('submitAddPostImg') && Tools::getValue('id_cms')!='')
             {		  
			 
             $output.=$this->addNewImage();	              	 
			 
			 }
		   
		   
		   else{
          		 
		    
		   $output.=$this->displayForm().'</br>'.$this->renderSubCategories().'</br>'.$this->InnovativesLabs();
          }
            return $output;
			
			
    }  
	
   
   
   
    // list subcats
      	public function renderSubCategories()
	{
		$fields_list = array(
		
		   'id_cms_category' => array(
				'title' => $this->l('ID Category'),
				'search' => false,
			),
			'name' => array(
				'title' => $this->l('Category Title'),
				'search' => false,
			)			
					
			
		);

		if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
			unset($fields_list['shop_name']);
		$helper_list = New HelperList();
		$helper_list->module = $this;
		$helper_list->title = $this->l('Blog: Subcategories');
		$helper_list->shopLinkType = '';
		$helper_list->no_link = true;
		$helper_list->show_toolbar = true;
		$helper_list->simple_header = false;
		$helper_list->identifier = 'id_cms_category';
		$helper_list->table = 'cms_category_lang';
		$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
		$helper_list->token = Tools::getAdminTokenLite('AdminModules');
		$helper_list->actions = array('view');
		$helper_list->bulk_actions = array(
			'select' => array(
				'text' => $this->l('Change order status'),
				'icon' => 'icon-refresh',				
			)
		); 		

		// This is needed for displayEnableLink to avoid code duplication
		$this->_helperlist = $helper_list;

		/* Retrieve list data */
		$id_cms_category=NSCmsBlogPro::loadDefaultCatery();
	    $orders=NSCmsBlogPro::getCMSCategories(false, (int)$id_cms_category);		
		$helper_list->listTotal = count($orders);

		/* Paginate the result */
		$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
		$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
		$orders = $this->paginateOrderProducts($orders, $page, $pagination);

		return $helper_list->generateList($orders, $fields_list);
		
	}
  
   
    public function paginateOrderProducts($orders, $page = 1, $pagination = 50)
	{
		if(count($orders) > $pagination)
			$orders= array_slice($orders, $pagination * ($page - 1), $pagination);

		return $orders;
	}  
  
   
	//pages list
	
	
	
	   public function 	renderPages()
	{
		$fields_list = array(
		
		   'id_cms' => array(
				'title' => $this->l('ID CMS'),
				'search' => false,
			),
			'meta_title' => array(
				'title' => $this->l('Title'),
				'search' => false,
			)		
			
		);

		if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
			unset($fields_list['shop_name']);
		$helper_list = New HelperList();
		$helper_list->module = $this;
		$helper_list->title = $this->l('CMS: Pages');
		$helper_list->shopLinkType = '';
		$helper_list->no_link = true;
		$helper_list->show_toolbar = true;
		$helper_list->simple_header = false;
		$helper_list->identifier = 'id_cms';
		$helper_list->table = 'cms_blog_img';
		$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
		$helper_list->token = Tools::getAdminTokenLite('AdminModules');
		$helper_list->actions = array('view','edit');
		$helper_list->bulk_actions = array(
			'select' => array(
				'text' => $this->l('Change order status'),
				'icon' => 'icon-refresh',				
			)
		); 		

		// This is needed for displayEnableLink to avoid code duplication
		$this->_helperlist = $helper_list;

		/* Retrieve list data */
		$id_shop =Context::getContext()->shop->id;
		$id_cms_category=(int)Tools::getValue('id_cms_category');		   
		$orders=NSCmsBlogPro::getCMSPages($id_cms_category, $id_shop);
		$helper_list->listTotal = count($orders);

		/* Paginate the result */
		$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
		$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
		$orders = $this->paginateOrderProducts($orders, $page, $pagination);

		return $helper_list->generateList($orders, $fields_list);
		
	}
	
	
	
	  	public function renderAddImage()
	{
	        $id_post=Tools::getValue('id_cms');
            $cms= new CMS($id_post, $this->context->language->id);	       
			
			$button = '<div class="panel"><a href="#">
                <button class="btn btn-default">Adding Image to CMS page : '.$cms->meta_title.'</button>
            </a></div>';
			
			
			
			
		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Add a Post Image'),
					
				),
				'input' => array(					
					array(
						'type' => 'hidden',
						'label' => $this->l('ID CMS'),
						'name' => 'id_cms',
						'desc' => $this->l('you are adding an image to this post.'),
					),
					array(
						'type' => 'file',
						'label' => $this->l('Post Image:'),
						'name' => 'BANNER_IMAGE',
						'class' => 'fixed-width-sm',
						'desc' => $this->l('Add the post associated image.'),
					),
				),
				'submit' => array(
					'title' => $this->l('Save'),
				)
			),
		);
		
		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table ='cms_blog_img';   // $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitAddPostImg';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);

		return $button.$helper->generateForm(array($fields_form));
	}
	
	public function getConfigFieldsValues()
	{
		return array(			
			'id_cms' => Tools::getValue('id_cms', Configuration::get('id_cms')),
			'BANNER_IMAGE' => Tools::getValue('BANNER_IMAGE', Configuration::get('BANNER_IMAGE')),
		);
	}
  
	
	
	   	   public function addNewImage(){	
	   
	   $output='';
	   $id_lang=(int)Context::getContext()->language->id; 
	   
     if(Tools::isSubmit('submitAddPostImg')){ 

	   
	   $id_cms=Tools::getValue('id_cms');
	  
	   
   if($id_cms!='' ){
		
        $BannerObj=PostImg::loadByIdPost($id_cms);		
		$BannerObj->id_post=$id_cms;	
		
		
		 if(!empty($BannerObj) && isset($BannerObj->id)){
		 
                 $BannerObj->update();
			     $BannerObj->processImage($_FILES,$BannerObj->id);	
	             $image_url=$BannerObj->id.'-small_default.jpg';				
		         $sql= 'UPDATE`'._DB_PREFIX_.'cms_blog_img` SET `img`=\''.pSQL($image_url).'\' 
		          WHERE `id_post`='.$BannerObj->id;                        
                  Db::getInstance()->execute($sql); 
        
		         $output=$this->displayConfirmation($this->l('Your image has been successfully added.'));
				 $output.='<br/><h1><a href="'. $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		         $output.='&id_cms='.$id_cms.'&viewcms_blog_img&token='.Tools::getAdminTokenLite('AdminModules');
		         $output.='">Preview Image</a></h1>';
        } else {
                 $BannerObj->add();
			     $BannerObj->processImage($_FILES,$BannerObj->id);	
	             $image_url=$BannerObj->id.'-small_default.jpg';				
		          $sql= 'UPDATE`'._DB_PREFIX_.'cms_blog_img` SET `img`=\''.pSQL($image_url).'\' 
		          WHERE `id_post`='.$BannerObj->id;                        
                  Db::getInstance()->execute($sql); 
        
		$output=$this->displayConfirmation($this->l('Your image has been successfully added.'));
		$output.='<br/><h1><a href="'. $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$output.='&id_cms='.$id_cms.'&viewcms_blog_img&token='.Tools::getAdminTokenLite('AdminModules');
		$output.='">Preview Image</a></h1>';
        }
				
		} else {$output=$this->displayError($this->l('All Field are required'));} 
      }   
	  
	  return $output;
   }
   
	
	
	public function getPostDetails(){
  
    $id_post=Tools::getValue('id_cms');
    $PostImg=PostImg::loadByIdPost($id_post);
    $cms= new CMS($id_post, $this->context->language->id);	
	
    $this->context->smarty->assign(
      array(      
		  'id_cms'=>(int)$id_post,	  
          'current_post'=>$PostImg, 
          'cms'=>$cms,		  
		  'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
		  
          
            )
               );  
  
  return $this->display(__FILE__, 'view_post.tpl');
  }
	
	

    
        public function hookDisplayHeader()
      {
           $this->context->controller->addCSS(($this->_path).'css/cmsblog.css', 'all');
      }    
   
  
  
      public function innovativesLabs(){
  
           $html='<br/>	 
	        <fieldset>			
			<iframe src="http://prestatuts.com/advertising/prestashop_advertising.html" width="100%" height="420px;" border="0" style="border:none;"></iframe>
			</fieldset>';
			
		return $html;	
  
      }
  
  
      public function hookdisplayHome()
   {
     
	 
	 $id_cms_category=NSCmsBlogPro::loadDefaultCatery();
	 $cmsCats=NSCmsBlogPro::getCMSCategories(false, (int)$id_cms_category);
	 $cmsPages=NSCmsBlogPro::getLatestPost($id_cms_category,false);
	  
	 $this->context->smarty->assign(array(	            				
                'cmsCats' =>$cmsCats,
                'id_cms_category'=>$id_cms_category,
                'Into_text'	=>Configuration::get('test_one'),
				'view_post_link' => $this->context->link->getModuleLink('cmsblogpro', 'post'),
				'home_blog_link' => $this->context->link->getModuleLink('cmsblogpro', 'home'),
                'cmsPages'=>$cmsPages				
		        
            ));
			
   
       return $this->display(__FILE__, 'displayHome.tpl');
		
   }
   
   
   public function hookdisplayTopColumn($params)
	{
		         
       return $this->display(__FILE__, 'post_img.tpl');
	}

  
  
  
  	   public function displayForm()
  {
    // Get default language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	$id_shop=Context::getContext()->shop->id;;
	$id_lang=(int)Context::getContext()->language->id; 
    
	
	//$cms_categories=CMSCategory::getCategories($id_lang,true,true);
	$cms_categories=CMSCategory::getSimpleCategories($id_lang);
    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Settings'),
			'icon' => 'icon-cogs'
        ),
        'input' => array(
            array(
                'type' => 'text',
                'label' => $this->l('Intro Text:'),
                'name' => 'test_one',
                'size' => 20,
                'required' => true,				
				'desc' => $this->l('add some text.')
            ),			

            array(
                'type' => 'text',
                'label' => $this->l('Post Number:'),
                'name' => 'POST_NUMBER',
                'size' => 20,
                'required' => true,
				'desc' => $this->l('How many articles to show in the home page.')
            ),				
			array(
					'type' => 'select',
					'label' => $this->l('Select a CMS Category'),
					'name' => 'id_cms_category',
					
					'options' => array(
						'query' =>$cms_categories,
						'id' => 'id_cms_category',
						'name' => 'name'
						
					),
					'desc' => $this->l('Select the default CMS category for the Blog.')
                      ),
					  
			 

      					  
        ),
        'submit' => array(
            'title' => $this->l('Save'),           
        )
    );
     
    $helper = new HelperForm();
     
    // Module, token and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
     
    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;
     
    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action = 'submit'.$this->name;
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );
     
    /*Load current value*/    
	
    $helper->fields_value['POST_NUMBER'] =Configuration::get('POST_NUMBER')? Configuration::get('POST_NUMBER'):Tools::getValue('POST_NUMBER');
	$helper->fields_value['id_cms_category'] =Configuration::get('id_cms_category')? Configuration::get('id_cms_category'):Tools::getValue('id_cms_category');
	
	$helper->fields_value['test_one'] =Configuration::get('test_one')? Configuration::get('test_one'):Tools::getValue('test_one');
	
	
     
    return $helper->generateForm($fields_form);
	
	
    }    

   
   
   
   
    //emptying the uploads Directory after uninstall 
  public function emptyUploads(){   
     foreach (new DirectoryIterator('../modules/cmsblogpro/uploads') as $file) 
     @unlink('../modules/cmsblogpro/uploads/'.$file);   
  }  
   
   
   
    //emptying the uploads Directory after uninstall 
  public function emptyCurrentImage($id){   
     foreach (new DirectoryIterator('../modules/cmsblogpro/uploads') as $file) 
	 if (strpos($file, $id) !== false) {
     @unlink('../modules/cmsblogpro/uploads/'.$file);  
    }	 
  }  
   
   
  
  
  }

