<?php
include_once('./../../config/config.inc.php');
include_once('./../../init.php');


$q=intval($_GET['q']);

    $id_lang=(int)Configuration::get('PS_LANG_DEFAULT');
    $id_feature=$q;      
	$features=FeatureValue::getFeatureValuesWithLang($id_lang, $id_feature,false);	
?>
<div class="col-lg-9 ">								
<select name="id_feature_value" class=" fixed-width-xl" id="id_feature_value" >
<?php 
foreach($features as $feature){
?>
<option value="<?php echo $feature['id_feature_value'];?>"><?php echo $feature['value'];?></option>
<?php 
}
?>
</select>					
</div>