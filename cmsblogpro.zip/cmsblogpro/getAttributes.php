<?php
include_once('./../../config/config.inc.php');
include_once('./../../init.php');


$q=intval($_GET['q']);

    $id_lang=(int)Configuration::get('PS_LANG_DEFAULT');
    $id_attribute_group=$q;  //(int)Tools::getValue('id_attribute_group');
    $attributeGroup=new AttributeGroup();  
	$attributes=$attributeGroup->getAttributes($id_lang, $id_attribute_group);
?>
<div class="col-lg-9 ">								
<select name="id_attribute" class=" fixed-width-xl" id="id_attribute" >
<?php 
foreach($attributes as $attribute){
?>
<option value="<?php echo $attribute['id_attribute'];?>"><?php echo $attribute['name'];?></option>
<?php 
}



?>
</select>					
</div>